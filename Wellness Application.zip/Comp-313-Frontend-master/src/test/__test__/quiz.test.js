import {render, screen, cleanup} from '@testing-library/react'
import '@testing-library/jest-dom'
import Quiz from '../../PublicUser/quiz'

afterEach(()=>{
    cleanup();
})

test('should render Quiz component',()=>{
    render(<Quiz/>);
    const quizElement = screen.getByTestId('quiz-test');
    expect(quizElement).toBeInTheDocument();
})