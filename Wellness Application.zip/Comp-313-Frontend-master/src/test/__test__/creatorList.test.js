import {render, screen, cleanup} from '@testing-library/react'
import '@testing-library/jest-dom'
import CreatorsList from '../../PublicUser/CreatorsList'

afterEach(()=>{
    cleanup();
})

test('should render CreatorsList component',()=>{
    render(<CreatorsList/>);
    const CreatorsListElement = screen.getByTestId('Creator-test-1');
    expect(CreatorsListElement).toBeInTheDocument();
})