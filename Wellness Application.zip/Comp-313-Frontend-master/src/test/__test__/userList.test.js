import {render, screen, cleanup} from '@testing-library/react'
import '@testing-library/jest-dom'
import UsersList from '../../PublicUser/UsersList'

afterEach(()=>{
    cleanup();
})

test('should render UsersList component',()=>{
    render(<UsersList/>);
    const UserListElement = screen.getByTestId('User-test-1');
    expect(UserListElement).toBeInTheDocument();
})