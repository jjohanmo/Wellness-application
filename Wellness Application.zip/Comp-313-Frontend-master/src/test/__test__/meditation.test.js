import {render, screen, cleanup} from '@testing-library/react'
import '@testing-library/jest-dom'
import Meditation from '../../PublicUser/Meditation'

afterEach(()=>{
    cleanup();
})

test('should render Meditation component',()=>{
    render(<Meditation/>);
    const meditationElement = screen.getByTestId('meditation-test');
    expect(meditationElement).toBeInTheDocument();
})