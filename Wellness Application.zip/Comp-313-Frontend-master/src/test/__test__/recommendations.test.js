import {render, screen, cleanup} from '@testing-library/react'
import '@testing-library/jest-dom'
import Recommendations from '../../PublicUser/recommendations'

afterEach(()=>{
    cleanup();
})

test('should render Recommendations component',()=>{
    render(<Recommendations/>);
    const recommendationsElement = screen.getByTestId('recommendations-test');
    expect(recommendationsElement).toBeInTheDocument();
})