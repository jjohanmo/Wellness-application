import {render, screen, cleanup} from '@testing-library/react'
import '@testing-library/jest-dom'
import Focus from '../../PublicUser/Focus'

afterEach(()=>{
    cleanup();
})

test('should render Focus component',()=>{
    render(<Focus/>);
    const focusElement = screen.getByTestId('focus-test');
    expect(focusElement).toBeInTheDocument();
})