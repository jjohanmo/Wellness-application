import React from 'react';
import ReactDOM from 'react-dom';
import MainMenu from './PublicUser/MainMenu';
import Dashboard from './PublicUser/dashboard';

import AdminDashboard from './PublicUser/adminDashboard';
import CreatorDashboard from './PublicUser/creatorDashboard';

import Welcome from './PublicUser/Welcome';
import About from './PublicUser/About';
import Features from './PublicUser/Features';
import MeditationVideo from './PublicUser/MeditationVideo';
import Testimonials from './PublicUser/Testimonials';
import FocusAudio from './PublicUser/FocusAudio';
import ContactInfo from './PublicUser/ContactInfo';
import Footer from './PublicUser/Footer';

import Login from './PublicUser/login'

import { Auth0Provider } from '@auth0/auth0-react';

import Quiz from './PublicUser/quiz';


import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
import CreateQuestions from './PublicUser/createQuestions';
import Content from './Creator/content';
import CreatorsList from './PublicUser/CreatorsList';
import UsersList from './PublicUser/UsersList';
import Meditation from './PublicUser/Meditation';
import Focus from './PublicUser/Focus';
import Recommendations from './PublicUser/recommendations';

const App = () => {
    return(
      <Router>
        <MainMenu/>
        <Routes>
          <Route path="/"element={
            <>
              <Welcome/>
              <About/>
              <Features/>
              <MeditationVideo/>
              <Testimonials/>
              <FocusAudio/>
              <ContactInfo/>
              <Footer/>
            </>
          }/>
          <Route path="/#about"  element={<About/>} />
          <Route path="/#work"  element={<MeditationVideo/>} />
          <Route path="/#product"  element={<FocusAudio/>} />
          <Route path="/#contact"  element={<ContactInfo/>} />
          <Route path="/login"  element={<Login/>} />
          <Route path="/dashboard"  element={<Dashboard/>} />
          <Route path="/adminDashboard"  element={<AdminDashboard/>} />
          <Route path="/creatorDashboard"  element={<CreatorDashboard/>} />
          <Route path="/quiz"  element={<Quiz/>} />
          <Route path="/createQuestions"  element={<CreateQuestions/>} />
          <Route path="/createContent"  element={<Content/>} />
          <Route path="/CreatorsList"  element={<CreatorsList/>} />
          <Route path="/UsersList"  element={<UsersList/>} />
          <Route path="/Meditation" element={<Meditation/>} />
          <Route path="/Focus" element={<Focus/>} />


          <Route path="/recommendations"  element={<Recommendations/>} />
        </Routes>
      </Router>
    )
}

const domain = process.env.REACT_APP_AUTH0_DOMAIN;
const clientId = process.env.REACT_APP_AUTH0_CLIENT_ID;

const getDashboardUri = () => {
  const userType = localStorage.getItem('userType')
  switch(userType){
    case '0':
      return 'http://localhost:3000/adminDashboard'
    case '1':
      return 'http://localhost:3000/creatorDashboard'
    case '2':
      return 'http://localhost:3000/dashboard'
    default:
        return 'http://localhost:3000/dashboard'
  }
}

ReactDOM.render(
  <Auth0Provider
    domain={domain}
    clientId={clientId}
    redirectUri={'http://localhost:3000/dashboard'}>
    <App />
  </Auth0Provider>,
  document.getElementById('root')
);