import {render, screen, cleanup} from '@testing-library/react'
import '@testing-library/jest-dom'
import Content from '../content'

afterEach(()=>{
    cleanup();
})

const { getId } =
  jest.requireActual('../../utils/getId')

describe('convert link', () => {
    it('normal link to embeded link', ()=>{
        expect(getId('https://www.youtube.com/watch?v=RGOj5yH7evk')).toBe('//www.youtube.com/embed/RGOj5yH7evk')
    })
})

test('should render Creator component',()=>{
    render(<Content/>);
    const contentElement = screen.getByTestId('content-test-1');
    expect(contentElement).toBeInTheDocument();
})