import { Button, TextField } from '@mui/material';
import React, {useState, useEffect} from 'react';
import '../styles/content.css'

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';

import { useAuth0 } from "@auth0/auth0-react";

function Content(props) {
    const { user } = useAuth0();
    const userId = localStorage.getItem('userId');
    const [open, setOpen] = React.useState(false);
    const [contentList, setContentList] = useState([])
    const [content, setContent] = useState({
        "Title": '',
        "Body": '',
        "UrlLink": '',
        "ContentCategoryId": 1,
        "ContentTypeId": 1,
        "IsDemoSample": false,
        "UserId": "10",
        "IsRemoved": false
    })
    const serverUrl = process.env.REACT_APP_FLASK_SERVER_URL;

    useEffect(()=>{
        fetchAllContent()
    },[])

    const fetchAllContent = () => {
        const userId = localStorage.getItem('userId');

        fetch(serverUrl+'/Content?user='+userId, {
            method: 'GET', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
        })
        .then((response) => response.json())
        .then((data) => {
            setContentList(data)


        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }

    const handleClickOpen = () => {
        setContent({
            "Title": '',
            "Body": '',
            "UrlLink": '',
            "ContentCategoryId": 1,
            "ContentTypeId": 1,
            "IsDemoSample": false,
            "UserId": userId,
            "IsRemoved": false
        })
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleCreate = () => {
        let url = serverUrl+'/CreateContent'

        if(content.ContentId){
            url = serverUrl+'/UpdateContent'
        }

        fetch(url, {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(content),
        })
        .then((response) => response.json())
        .then((data) => {

            fetchAllContent()
        })
        .catch((error) => {
            console.error('Error:', error);
        });
        setOpen(false);
    }

    const getId = (url) => {
        const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
        const match = url.match(regExp);

        const result = (match && match[2].length === 11)
          ? match[2]
          : null;

        return '//www.youtube.com/embed/' + result;
    }

    const handleEdit = (content) => {
        setContent(content)
        setOpen(true);
    }

    const handleContentDelete = (contentId) =>{
        fetch(serverUrl+ '/'+contentId+'/DeleteContent', {
            method: 'GET', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then((response) => response.json())
        .then((data) => {
            fetchAllContent()
            // window.location.reload();

        })
        .catch((error) => {
            console.error('Error:', error);
        });
        setOpen(false);
    }

    const handleValueChange = (e,field) => {
        content[field] = e.target.value;
        setContent({...content})
    }

    const [contentType, setContentType] = React.useState('');
    const [contentCategory, setContentCategory] = React.useState('')

    const handleChangeContentType = (event) => {
        setContentType(event.target.value);
    };

    const handleChangeContentCategory = (event) => {
        setContentCategory(event.target.value);
    };

    return (
        <div data-testid="content-test-1" className="content-container" style={{marginTop:'200px'}}>
            <div>
            <Dialog open={open} onClose={handleClose}>
                    <DialogTitle>Create Content</DialogTitle>
                    <DialogContent>
                    <DialogContentText>
                        To subscribe to this website, please enter your email address here. We
                        will send updates occasionally.
                    </DialogContentText>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="title"
                        label="Title"
                        type="string"
                        value={content.Title ?? ''}
                        onChange={(e)=>handleValueChange(e,'Title')}
                        fullWidth
                        variant="standard"
                    />
                    <FormControl variant="standard" fullWidth>
                        <InputLabel id="demo-simple-select-standard-label">Content Category</InputLabel>
                        <Select
                        labelId="demo-simple-select-standard-label"
                        id="demo-simple-select-standard"
                        value={contentCategory}
                        onChange={handleChangeContentCategory}
                        label="Content Category"
                        >
                        <MenuItem value={'focus'}>Focus</MenuItem>
                        <MenuItem value={'meditation'}>Meditation</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl variant="standard" fullWidth>
                        <InputLabel id="demo-simple-select-standard-label">Content Type</InputLabel>
                        <Select
                        labelId="demo-simple-select-standard-label"
                        id="demo-simple-select-standard"
                        value={contentType}
                        onChange={handleChangeContentType}
                        label="Content Type"
                        >
                        <MenuItem value={'video'}>Video</MenuItem>
                        <MenuItem value={'audio'}>Audio</MenuItem>
                        </Select>
                    </FormControl>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="url"
                        label="Content URL Link"
                        type="string"
                        value={content.UrlLink ?? ''}
                        onChange={(e)=>handleValueChange(e,'UrlLink')}
                        fullWidth
                        variant="standard"
                    />
                    <TextField
                        autoFocus
                        margin="dense"
                        id="body"
                        label="Body"
                        type="string"
                        value={content.Body ?? ''}
                        onChange={(e)=>handleValueChange(e,'Body')}
                        fullWidth
                        variant="standard"
                    />
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleCreate}>Create</Button>
                    </DialogActions>
                </Dialog>
            </div>
            <Button className="create-button" onClick={()=>handleClickOpen()} variant="contained">+ Create Content</Button>
            <table>
                <tbody>
                <tr>
                    <th>Title</th>
                    <th className="content">URL</th>
                    <th>Body</th>
                    <th>Actions</th>
                </tr>
                {
                contentList.map((val, key) => {
                    return (
                        <React.Fragment>
                        {
                            !val.IsRemoved &&
                            <tr key={key}>
                            <td>{val.Title}</td>
                            <td className="content">
                                <iframe width="420" height="315" src={getId(val.UrlLink)} frameborder="0" allowFullScreen></iframe>
                            </td>
                            <td>{val.Body}</td>
                            <td className="actions">
                                <Button onClick={()=>handleEdit(val)}>Edit</Button>
                                <Button onClick={()=>handleContentDelete(val.ContentId)}>Delete</Button>
                            </td>
                            </tr>

                        }
                        </React.Fragment>
                    )
                    })
                }
                </tbody>
            </table>
        </div>
    );
}

export default Content;