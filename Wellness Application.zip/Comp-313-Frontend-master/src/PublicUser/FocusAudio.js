import React from 'react';
import about from '../images/about.jpg'
import med from '../images/med.jpg'
import meditation from '../images/meditation-21.jpg'

import audio from '../images/audio.MP3'



const FocusAudio = () => {
    return (
       
<section id="product" className="mt-5 pb-5">
  <div className="container ">
    <div className="row  ">
      <div className="col-md-4 ">
        <div className="card  text-center pt-3">
          <div className="card-img">
            <img src={about} className="img-fluid my-3" style={{width: '200px', height: '150px'}} alt="" />
          </div>
          <div className="card-body">
            <h3 className="section-title">Focus <span>Audio</span></h3>
            <p>“To know one's own mind is nothing short of life-changing."</p>
            <audio controls>
              <source src={audio} type="audio/mpeg" />
            </audio>
          </div>
        </div>
      </div>
      <div className="col-md-4 ">
        <div className="card  text-center pt-3">
          <div className="card-img">
            <img src={med} className="img-fluid my-3" style={{width: '200px', height: '150px'}} alt="" />
          </div>
          <div className="card-body">
            <h3 className="section-title">Focus <span>Audio</span></h3>
            <p>“To know one's own mind is nothing short of life-changing."</p>
            <audio controls>
              <source src={audio} type="audio/mpeg" />
            </audio>
          </div>
        </div>
      </div>
      <div className="col-md-4 ">
        <div className="card  text-center pt-3">
          <div className="card-img">
            <img src={meditation} className="img-fluid my-3" style={{width: '200px', height: '150px'}} alt="" />
          </div>
          <div className="card-body">
            <h3 className="section-title">Focus <span>Audio</span></h3>
            <p>“To know one's own mind is nothing short of life-changing."</p>
            <audio controls>
              <source src={audio} type="audio/mpeg" />
            </audio>
          </div>
        </div>
      </div>
    </div>
  </div>
  <section>
  </section></section>
    ) 
}
    export default FocusAudio;