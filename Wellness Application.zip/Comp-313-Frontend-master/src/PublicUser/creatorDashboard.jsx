import React from 'react';

function CreatorDashboard(props) {
    return (
        <div>

        </div>
    );
}

export default CreatorDashboard;