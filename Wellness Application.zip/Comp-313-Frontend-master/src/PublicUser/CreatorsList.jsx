import { Button, TextField } from '@mui/material';
import React, {useState, useEffect} from 'react';
import '../styles/user.css'

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogUser from '@mui/material/DialogContent';
import DialogUserText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';


import { useAuth0 } from "@auth0/auth0-react";

function User(props) {
    const { user } = useAuth0();
    const [open, setOpen] = React.useState(false);
    const [UserList, setUserList] = useState([])
    const [User, setUser] = useState({
        "FirstName": '',
        "LastName": '',
        "Email": '',
        "RoleId": '3',
        "StatusId": 1,
        "RegisterDate": false,
        "UserId": '',
        "IsDeleted": false
    })
    const serverUrl = process.env.REACT_APP_FLASK_SERVER_URL;

    useEffect(()=>{
        fetchAllUser()
    },[])

    const fetchAllUser = () => {
        fetch(serverUrl+'/Users?isDemo=0&roleId=2', {
            method: 'GET', // or 'PUT'
            headers: {
                'User-Type': 'application/json',
            },
        })
        .then((response) => response.json())
        .then((data) => {
            setUserList(data)


        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }

    const handleClickOpen = () => {
        setUser({
            "FirstName": '',
            "LastName": '',
            "Email": '',
            "RoleId": 1,
            "StatusId": 1,
            "RegisterDate": false,
            "UserId": '',
            "IsDeleted": false
        })
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleCreate = () => {
        console.log("User", User)
        let url = serverUrl+'/AddNewUser'

        if(User.UserId){
            url = serverUrl+'/UpdateUser'
        }

        fetch(url, {
            method: 'POST', // or 'PUT'
            headers: {
                'User-Type': 'application/json',
            },
            body: JSON.stringify(User),
        })
        .then((response) => response.json())
        .then((data) => {

            console.log("asddas", data)
            fetchAllUser()
        })
        .catch((error) => {
            console.error('Error:', error);
        });
        setOpen(false);
    }


    const handleEdit = (User) => {
        setUser(User)
        setOpen(true);
    }

    const handleUserDelete = (UserId) =>{
        console.log("delete", UserId)

        fetch(serverUrl+ '/'+UserId+'/DeleteUser', {
            method: 'GET', // or 'PUT'
            headers: {
                'User-Type': 'application/json',
            }
        })
        .then((response) => response.json())
        .then((data) => {

            console.log("delete res", data)
            fetchAllUser()
            // window.location.reload();

        })
        .catch((error) => {
            console.error('Error:', error);
        });
        setOpen(false);
    }

    const handleValueChange = (e,field) => {
        User[field] = e.target.value;
        setUser({...User})
    }
    // console.log("UserList", UserList)
    return (
        <div data-testid="Creator-test-1" className="User-container" style={{marginTop:'200px'}}>
            <div>
            <Dialog open={open} onClose={handleClose}>
                    <DialogTitle>Create User</DialogTitle>
                    <DialogUser>
                    <DialogUserText>
                        Create a User
                    </DialogUserText>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="UserId"
                        label="User Id"
                        type="string"
                        value={User.FirstName ?? ''}
                        onChange={(e)=>handleValueChange(e,'UserId')}
                        fullWidth
                        variant="standard"
                    />
                    <TextField
                        autoFocus
                        margin="dense"
                        id="firstname"
                        label="First Name"
                        type="string"
                        value={User.FirstName ?? ''}
                        onChange={(e)=>handleValueChange(e,'FirstName')}
                        fullWidth
                        variant="standard"
                    />
                     <TextField
                        autoFocus
                        margin="dense"
                        id="lastname"
                        label="Last Name"
                        type="string"
                        value={User.LastName ?? ''}
                        onChange={(e)=>handleValueChange(e,'LastName')}
                        fullWidth
                        variant="standard"
                    />
                     <TextField
                        autoFocus
                        margin="dense"
                        id="email"
                        label="Email"
                        type="string"
                        value={User.Email ?? ''}
                        onChange={(e)=>handleValueChange(e,'Email')}
                        fullWidth
                        variant="standard"
                    />
                    </DialogUser>
                    {/* <DialogActions>
                    <Button onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleCreate}>Create</Button>
                    </DialogActions> */}
                </Dialog>
            </div>

            <table>
                <tbody>
                <tr>
                <th>User ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    {/* <th>Actions</th> */}
                </tr>
                {
                UserList.map((val, key) => {
                    return (
                        <React.Fragment>
                        {
                            !val.IsRemoved &&
                            <tr key={key}>
                                     <td>{val.UserId}</td>
                             <td>{val.FirstName}</td>
                            <td>{val.LastName}</td>
                            <td>{val.Email}</td>
                            {/* <td className="actions">
                                <Button onClick={()=>handleEdit(val)}>Edit</Button>
                                <Button onClick={()=>handleUserDelete(val.UserId)}>Delete</Button>
                            </td> */}
                            </tr>

                        }
                        </React.Fragment>
                    )
                    })
                }
                </tbody>
            </table>
        </div>
    );
}

export default User;