import { Button, TextField } from '@mui/material';
import React, {useState, useEffect} from 'react';
import '../styles/content.css'

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import { useAuth0 } from "@auth0/auth0-react";

function Content(props) {
    const { user } = useAuth0();
    const [open, setOpen] = React.useState(false);
    const [contentList, setContentList] = useState([])
    const [content, setContent] = useState({
        "Title": '',
        "Body": '',
        "UrlLink": '',
        "ContentCategoryId": 1,
        "ContentTypeId": 2,
        "IsDemoSample": false,
        "UserId": "10",
        "IsRemoved": false
    })
    const serverUrl = process.env.REACT_APP_FLASK_SERVER_URL;

    useEffect(()=>{
        fetchAllContent()
    },[])

    const fetchAllContent = () => {
        fetch(serverUrl+'/Content?isDemo=0', {
            method: 'GET', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
        })
        .then((response) => response.json())
        .then((data) => {
            setContentList(data)
            const result = data.filter(c=>{
                return Number(c.ContentCategoryId) > 3
            })
            console.log('result',result)
            setContentList(result)


        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }

    const handleClickOpen = () => {
        setContent({
            "Title": '',
            "Body": '',
            "UrlLink": '',
            "ContentCategoryId": 1,
            "ContentTypeId": 1,
            "IsDemoSample": false,
            "UserId": "10",
            "IsRemoved": false
        })
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleCreate = () => {
        console.log("content", content)
        let url = serverUrl+'/CreateContent'

        if(content.ContentId){
            url = serverUrl+'/UpdateContent'
        }

        fetch(url, {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(content),
        })
        .then((response) => response.json())
        .then((data) => {

            console.log("asddas", data)
            fetchAllContent()
        })
        .catch((error) => {
            console.error('Error:', error);
        });
        setOpen(false);
    }

    const getId = (url) => {
        const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
        const match = url.match(regExp);

        const result = (match && match[2].length === 11)
          ? match[2]
          : null;

        return '//www.youtube.com/embed/' + result;
    }

    const handleEdit = (content) => {
        setContent(content)
        setOpen(true);
    }

    const handleContentDelete = (contentId) =>{
        console.log("delete", contentId)

        fetch(serverUrl+ '/'+contentId+'/DeleteContent', {
            method: 'GET', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then((response) => response.json())
        .then((data) => {

            console.log("delete res", data)
            fetchAllContent()
            // window.location.reload();

        })
        .catch((error) => {
            console.error('Error:', error);
        });
        setOpen(false);
    }

    const handleValueChange = (e,field) => {
        content[field] = e.target.value;
        setContent({...content})
    }

    return (
        <div data-testid="focus-test" className="content-container" style={{marginTop:'200px'}}>
            <div>
            <Dialog open={open} onClose={handleClose}>
                    <DialogTitle>Create Content</DialogTitle>
                    <DialogContent>
                    <DialogContentText>
                        To subscribe to this website, please enter your email address here. We
                        will send updates occasionally.
                    </DialogContentText>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="title"
                        label="Title"
                        type="string"
                        value={content.Title ?? ''}
                        onChange={(e)=>handleValueChange(e,'Title')}
                        fullWidth
                        variant="standard"
                    />
                    <TextField
                        autoFocus
                        margin="dense"
                        id="url"
                        label="Content URL Link"
                        type="string"
                        value={content.UrlLink ?? ''}
                        onChange={(e)=>handleValueChange(e,'UrlLink')}
                        fullWidth
                        variant="standard"
                    />
                    <TextField
                        autoFocus
                        margin="dense"
                        id="body"
                        label="Body"
                        type="string"
                        value={content.Body ?? ''}
                        onChange={(e)=>handleValueChange(e,'Body')}
                        fullWidth
                        variant="standard"
                    />
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleCreate}>Create</Button>
                    </DialogActions>
                </Dialog>
            </div>

            <table>
                <tbody>
                <tr>
                    <th>Title</th>
                    <th className="content">URL</th>
                    <th>Body</th>

                </tr>
                {
                contentList.map((val, key) => {
                    return (
                        <React.Fragment>
                        {
                            !val.IsRemoved &&
                            <tr key={key}>
                            <td>{val.Title}</td>
                            <td className="content">
                                <iframe width="420" height="315" src={getId(val.UrlLink)} frameborder="0" allowFullScreen></iframe>
                            </td>
                            <td>{val.Body}</td>

                            </tr>

                        }
                        </React.Fragment>
                    )
                    })
                }
                </tbody>
            </table>
        </div>
    );
}

export default Content;