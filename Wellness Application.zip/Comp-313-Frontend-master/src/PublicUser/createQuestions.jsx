import React, {useState, useEffect} from 'react';
import TextField from '@mui/material/TextField';
import { Button } from '@mui/material';

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import '../styles/createQuestions.css'

function CreateQuestions(props) {
    const [open, setOpen] = React.useState(false);
    const serverUrl = process.env.REACT_APP_FLASK_SERVER_URL;

    const [questionList, setQuestionList] = useState([])
    const [question, setQuestion] = useState({
        "IsDeleted": false,
        "Statement": "",
        "QuestionCategory":
            {
                "Name": "Demographics",
                "QuestionCategoryId": 1
            },
        "QuestionCategoryId": 1,
        "QuestionChoices":[
            {
                "Label": "",
                "OrderNumber": 1,
                "IsDeleted": false
            },
            {
                "Label": "",
                "OrderNumber": 2,
                "IsDeleted": false
            },
            {
                "Label": "",
                "OrderNumber": 3,
                "IsDeleted": false
            },
            {
                "Label": "",
                "OrderNumber": 4,
                "IsDeleted": false
            }
        ]
    })

    useEffect(()=>{
        fetchAllQuestions()
    },[])

    const fetchAllQuestions = () => {
        fetch(serverUrl+'/Questions', {
            method: 'GET', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then((response) => response.json())
        .then((data) => {
            setQuestionList(data)

        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }


    const handleClickOpen = () => {
        setQuestion({
            "IsDeleted": false,
            "Statement": "",
            "QuestionCategory":
                {
                    "Name": "Demographics",
                    "QuestionCategoryId": 1
                },
            "QuestionCategoryId": 1,
            "QuestionChoices":[
                {
                    "Label": "",
                    "OrderNumber": 1,
                    "IsDeleted": false
                },
                {
                    "Label": "",
                    "OrderNumber": 2,
                    "IsDeleted": false
                },
                {
                    "Label": "",
                    "OrderNumber": 3,
                    "IsDeleted": false
                },
                {
                    "Label": "",
                    "OrderNumber": 4,
                    "IsDeleted": false
                }
            ]
        })
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleCreate = () => {
        let url = serverUrl+'/CreateQuestion'

        if(question.QuestionId){
            url = serverUrl+'/UpdateQuestion'
        }

        fetch(url, {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(question),
        })
        .then((response) => response.json())
        .then((data) => {
            fetchAllQuestions()
        })
        .catch((error) => {
            console.error('Error:', error);
        });
        setOpen(false);
    }

    const handleValueChange = (e,field,position) => {
        if( field === 'Statement'){
            question['Statement'] = e.target.value
        }else{
            question[field][position]['Label'] = e.target.value
        }
        setQuestion({...question})
    }

    const handleEdit = (question) => {
        setQuestion(question)
        setOpen(true);
    }

    const handleQuestionDelete = (questionId) =>{
        fetch(serverUrl+'/DeleteQuestion/'+ questionId+'/', {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then((response) => response.json())
        .then((data) => {
            fetchAllQuestions()

        })
        .catch((error) => {
            fetchAllQuestions()
            console.error('Error:', error);
        });
        setOpen(false);
    }

    return (
        <div>
            <div style={{marginTop:'200px'}}>
                <Button className="create-button" variant="contained" onClick={handleClickOpen}> + Create a new question</Button>
                <Dialog open={open} onClose={handleClose}>
                    <DialogTitle>Create question</DialogTitle>
                    <DialogContent>
                    <DialogContentText>
                        To subscribe to this website, please enter your email address here. We
                        will send updates occasionally.
                    </DialogContentText>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="Question"
                        label="Question"
                        type="string"
                        value={question.Statement ?? ""}
                        onChange={(e)=>handleValueChange(e,'Statement')}
                        fullWidth
                        variant="standard"
                    />
                    <TextField
                        autoFocus
                        margin="dense"
                        id="option1"
                        label="Option #1"
                        type="string"
                        value={question.QuestionChoices[0] ? question.QuestionChoices[0]['Label'] : ""}
                        onChange={(e)=>handleValueChange(e,'QuestionChoices',0)}
                        fullWidth
                        variant="standard"
                    />
                    <TextField
                        autoFocus
                        margin="dense"
                        id="option2"
                        label="Option #2"
                        type="string"
                        value={question.QuestionChoices[1] ? question.QuestionChoices[1]['Label'] : ""}
                        onChange={(e)=>handleValueChange(e,'QuestionChoices',1)}
                        fullWidth
                        variant="standard"
                    />
                    <TextField
                        autoFocus
                        margin="dense"
                        id="option3"
                        label="Option #3"
                        type="string"
                        value={question.QuestionChoices[2] ? question.QuestionChoices[2]['Label'] : ""}
                        onChange={(e)=>handleValueChange(e,'QuestionChoices',2)}
                        fullWidth
                        variant="standard"
                    />
                    <TextField
                        autoFocus
                        margin="dense"
                        id="option4"
                        label="Option #4"
                        type="string"
                        value={question.QuestionChoices[3] ? question.QuestionChoices[3]['Label'] :""}
                        onChange={(e)=>handleValueChange(e,'QuestionChoices',3)}
                        fullWidth
                        variant="standard"
                    />
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleCreate}>Create</Button>
                    </DialogActions>
                </Dialog>
            </div>
            <div>
                <table>
                    <tr>
                        <th className="question-column">Question</th>
                        <th>Option1</th>
                        <th>Option2</th>
                        <th>Option3</th>
                        <th>Option4</th>
                        <th>Actions</th>
                    </tr>
                    {
                    questionList.map((question, key) => {
                        return (
                            <React.Fragment>
                            {
                            !question.IsDeleted &&
                                <tr key={key}>
                                <td className="question-column">{question.Statement}</td>


                                <td>{question.QuestionChoices[0] ? question.QuestionChoices[0].Label : ""}</td>
                                <td>{question.QuestionChoices[1] ? question.QuestionChoices[1].Label : ""}</td>
                                <td>{question.QuestionChoices[2] ? question.QuestionChoices[2].Label : ""}</td>
                                <td>{question.QuestionChoices[3] ? question.QuestionChoices[3].Label : ""}</td>

                                <td>
                                    <Button onClick={()=>handleEdit(question)}>Edit</Button>
                                    <Button onClick={()=>handleQuestionDelete(question.QuestionId)}>Delete</Button>
                                </td>
                                </tr>
                            }
                            </React.Fragment>
                        )
                        })
                    }

                </table>
            </div>
        </div>
    );
}

export default CreateQuestions;