import React from 'react';


const Footer = () => {
    return (
<section id="footer">
  <div className="footer container">
    <div className="brand">
      <h1>Wellness</h1>
    </div>
    <h2 />
    <div className="social-icon">
      <div className="social-item">
        <a href="https://www.facebook.com/centennialcollege" target="_blank"><img src="https://img.icons8.com/fluent/48/000000/facebook-new.png" /></a>
      </div>
      <div className="social-item">
        <a href="https://www.instagram.com/centennialcollege" target="_blank"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png" /></a>
      </div>
      <div className="social-item">
        <a href="https://twitter.com/centennialEDU" target="_blank"><img src="https://img.icons8.com/fluent/48/000000/twitter.png" /></a>
      </div>
    </div>
    <p>Copyright © 2022 Wellness. All rights reserved</p>
  </div>
</section>

    )
}
export default Footer;