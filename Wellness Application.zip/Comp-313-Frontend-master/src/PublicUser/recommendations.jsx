import React, {useState, useEffect} from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import { positions } from '@mui/system';


function Recommendations(props) {

    const [showLoader, setShowLoader] = useState(true)
    const [progress, setProgress] = useState(0)

    useEffect(
        () => {
          let timer1 = setTimeout(() => {
                setShowLoader(false)
                setProgress(50)
            }, 5000);

          // this will clear Timeout
          // when component unmount like in willComponentUnmount
          // and show will not change to true
          return () => {
            clearTimeout(timer1);
          };
        },
        // useEffect will run only one time with empty []
        // if you pass a value to array,
        // like this - [data]
        // than clearTimeout will run every time
        // this value changes (useEffect re-run)
        []
      );

    const content = JSON.parse(localStorage.getItem('recommendations'))

    const getId = (url) => {
        const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
        const match = url.match(regExp);

        const result = (match && match[2].length === 11)
          ? match[2]
          : null;

        return '//www.youtube.com/embed/' + result;
    }

    return (
        <div data-testid="recommendations-test" style={{marginTop: '200px', position: 'relative'}}>
            {
                showLoader ?
                <div style={{position:'absolute', left: '50%', top: '50%'}}>
                    <CircularProgress size={60} value={progress} color="secondary" />
                </div>

                :
                <div>
                    <h3 style={{textAlign: 'center', marginBottom:'40px'}}>Top Recommendations</h3>
                    <table>
                        <tbody>
                        <tr>
                            <th>Title</th>
                            <th className="content">URL</th>
                            <th>Body</th>
                        </tr>
                        {
                        content.map((val, key) => {
                            return (
                                <React.Fragment>
                                {
                                    <tr key={key}>
                                    <td>{val.Title}</td>
                                    <td className="content">
                                        <iframe width="420" height="315" src={getId(val.UrlLink)} frameborder="0" allowFullScreen></iframe>
                                    </td>
                                    <td>{val.Body}</td>
                                    {/* <td className="actions">
                                        <Button onClick={()=>handleEdit(val)}>Edit</Button>
                                        <Button onClick={()=>handleContentDelete(val.ContentId)}>Delete</Button>
                                    </td> */}
                                    </tr>

                                }
                                </React.Fragment>
                            )
                            })
                        }
                        </tbody>
                    </table>
                </div>
            }



        </div>
    );
}

export default Recommendations;