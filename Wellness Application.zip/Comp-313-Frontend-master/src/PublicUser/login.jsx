import React, {useState} from 'react';
import '../styles/login.css'

import ButtonCustom from './buttonCustom';

const Login = (props) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const postFormData = () => {

    }

    return (
    <div className="wrapper fadeInDown">
    <div id="formContent">
        <h2 className="active"> Login to Wellness </h2>
        <form>
            <input
                name="email"
                type="string"
                placeholder="Email ID"
                value={email}
                onChange={e => setEmail(e.target.value)}
            />
            <br/><br/><br/>

            <input
                name="password"
                type="password"
                placeholder="Password"
                value={password}
                onChange={e => setPassword(e.target.value)}
            />

            <ButtonCustom id="login-button" className="btn btn-success button-style" onClick={()=>{postFormData()}} label="Login"/>
            <br/>
        </form>
    </div>
    </div>
    );
}

export default Login;