import React from 'react';
import about from '../images/about.jpg'
import med from '../images/med.jpg'
import meditation from '../images/meditation-21.jpg'
import logo from '../images/logo.png'




const Testimonials = () => {
    return (
        <section id="testimonials" className="py-5">
        <div className="container-fluid">
          <div className="row">
            <div className="column mx-auto">
              <div id="myCarousel" className="carousel slide" data-ride="carousel">
                <ol className="carousel-indicators">
                  <li data-target="#myCarousel" data-slide-to={0} className="active" />
                  <li data-target="#myCarousel" data-slide-to={1} />
                  <li data-target="#myCarousel" data-slide-to={2} />
                </ol>
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img src={med} className="img-fluid " />
                    <div className="carousel-caption d-none d-md-block">
                      <h3 className="section-title">Wellness App <span>Testimonial</span></h3>
                      <p>“So much time and effort is spent on wanting to change, trying to change, to be somebody different, better, or new. Why not use this time to get comfortable with yourself as you are instead?” -Andy Puddicombe, Headspace co-founder</p>
                    </div>
                  </div>
                  <div className="carousel-item">
                    <img src={meditation} className="d-block w-100" alt="..." />
                    <div className="carousel-caption d-none d-md-block">
                      <h3 className="section-title">Wellness App <span>Testimonial</span></h3>
                      <p>“To know one's own mind is nothing short of life-changing. -@Headspace, #mindfulmoments</p>
                    </div>
                  </div>
                  <div className="carousel-item">
                    <img src={med} className="d-block w-100" alt="..." />
                    <div className="carousel-caption d-none d-md-block">
                      <h3 className="section-title">Wellness App <span>Testimonial</span></h3>
                      <p>“In the midst of movement and chaos, keep stillness inside of you.” -Anonymous</p>
                    </div>
                  </div>
                </div>
                <a className="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                  <span className="carousel-control-prev-icon" aria-hidden="true" />
                  <span className="sr-only">Previous</span>
                </a>
                <a className="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                  <span className="carousel-control-next-icon" aria-hidden="true" />
                  <span className="sr-only">Next</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    ) 
}
    export default Testimonials;