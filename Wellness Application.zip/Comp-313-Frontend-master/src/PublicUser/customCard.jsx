import React, { useEffect, useState }  from 'react';
import { styled } from '@mui/material/styles';

import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import '../styles/customCard.css'

function CustomCard(props) {

    const { question, selectAnswer, answer, setAnswer } = props;

    return (
        <div className="card-container">
            <h4 className="question">{question?.Statement}</h4>
            <div className="answer-container">
                <Box sx={{ flexGrow: 1 }}>
                    <Grid container spacing={4}>
                        <Grid item xs={6}>
                            <h5 className={answer === 0 || question?.userResponse === 1 ? 'option-answer' : 'option'} onClick={()=>{selectAnswer(0);setAnswer(0)}}>{question?.QuestionChoices[0]['Label']}</h5>
                        </Grid>
                        <Grid item xs={6}>
                            <h5 className={answer === 1 || question?.userResponse === 2 ? 'option-answer' : 'option'}  onClick={()=>{selectAnswer(1);setAnswer(1)}}>{question?.QuestionChoices[1]['Label']}</h5>
                        </Grid>
                        <Grid item xs={6}>
                            <h5 className={answer === 2 || question?.userResponse === 3 ? 'option-answer' : 'option'}  onClick={()=>{selectAnswer(2);setAnswer(2)}}>{question?.QuestionChoices[2]['Label']}</h5>
                        </Grid>
                        <Grid item xs={6}>
                            <h5 className={answer === 3 || question?.userResponse === 4 ? 'option-answer' : 'option'}  onClick={()=>{selectAnswer(3);setAnswer(3)}}>{question?.QuestionChoices[3]['Label']}</h5>
                        </Grid>
                    </Grid>
                </Box>
            </div>
        </div>
    );
}

export default CustomCard;