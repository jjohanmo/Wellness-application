import React from 'react';
import '../styles/buttonCustom.css'
function ButtonCustom({label, onClick}) {
  return (
    <div data-testid="button" className="button-style" onClick={()=>onClick()}>
        {label}
    </div>
  );
}

export default ButtonCustom;
