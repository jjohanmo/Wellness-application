import React from 'react';

const ContactInfo = () => {
    return (

        <section id="contact">
        <div className="contact container">
          <h2 className="section-title">Contact<span> Info</span></h2>
          <div className="contact-items">
            <br />
            <div className="contact-item">
              <div className="icon"><img src="https://img.icons8.com/external-kiranshastry-lineal-color-kiranshastry/64/000000/external-phone-call-logistic-delivery-kiranshastry-lineal-color-kiranshastry.png" /></div>
              <div className="contact-info">
                <h1>Phone</h1>
                <span style= { {color: 'black'}}>1800-300-11111</span>
              </div>
            </div>
            <div className="contact-item">
              <div className="icon"><img src="https://img.icons8.com/external-icongeek26-linear-colour-icongeek26/64/000000/external-email-alert-icongeek26-linear-colour-icongeek26.png" /></div>
              <div className="contact-info">
                <h1>Email</h1>
                <span style= { {color: 'black'}}>info@wellness.org</span>
              </div>
            </div>
            <div className="contact-item">
              <div className="icon"><img src="https://img.icons8.com/nolan/64/address.png" /></div>
              <div className="contact-info">
                <h1>Address</h1>
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d184552.5728977692!2d-79.51814188580819!3d43.71815566201939!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb90d7c63ba5%3A0x323555502ab4c477!2sToronto%2C%20ON!5e0!3m2!1sen!2sca!4v1665554292033!5m2!1sen!2sca" width={125} height={250} style={{border: 0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />


              </div>
            </div>
          </div>
        </div>
      </section>
    )
}
    export default ContactInfo;