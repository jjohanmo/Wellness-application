import React from 'react';
import '../index.css';

import logomenu from "../images/logomenu.png"

import { useAuth0 } from '@auth0/auth0-react';

const MainMenu = () => {
    const {loginWithRedirect,logout} = useAuth0();


    const login = (userType) => {
      localStorage.setItem('userType', userType)
      loginWithRedirect()
    }

    const logoutUser = () => {
      localStorage.removeItem('userType');
      localStorage.removeItem('userData');
      logout();
    }

    const userType = localStorage.getItem('userType')

    return (
        <section id="header">
        <div className="header container">
          <div className="nav-bar">
            <div className="brand">
              <a href="#home">
                <img src={logomenu} alt="Logo" style={{height: '40px', width: '40px'}} />
              </a>
            </div>
            <div className="nav-list">
              <div className="hamburger">
                <div className="bar" />
              </div>
              <ul>
                {
                  (!userType) &&
                  <div>
                    <li><a href="#home" data-after="Home">Home</a></li>
                    <li><a href="#about" data-after="About">About Us</a></li>
                    <li><a href="#work" data-after="Meditation">Meditation</a></li>
                    <li><a href="#product" data-after="Focus">Focus</a></li>
                    <li><a href="#contact" data-after="Contact">Contact Us</a></li>
                    <li><a style={{cursor: 'pointer'}} onClick={() => login(2)} data-after="Login">Login</a></li>
                    <li><a style={{cursor: 'pointer'}} onClick={() => login(1)} data-after="Login">Creator</a></li>
                    <li><a style={{cursor: 'pointer'}} onClick={() => login(0)} data-after="Login">Admin</a></li>
                  </div>
                }
                {
                  (userType && userType === '2') &&
                  <div>
                    <li><a href="/quiz" data-after="quiz">Quiz</a></li>
                    <li><a href="/Meditation" data-after="Meditation">Meditation</a></li>
                    <li><a href="/Focus" data-after="Focus">Focus</a></li>
                    <li><a style={{cursor: 'pointer'}} onClick={() => logoutUser()} data-after="logout">Log out</a></li>
                  </div>
                }
                {
                  (userType && userType === '0') &&
                  <div>
                    <li><a href="/quiz" data-after="quiz">Quiz</a></li>
                    <li><a href="/createQuestions" data-after="create-questions">Create Questions</a></li>
                    <li><a href="/createContent" data-after="Library">Content</a></li>
                    <li><a href="/CreatorsList" data-after="Creators List">Creators List</a></li>
                    <li><a href="/UsersList" data-after="Users List">Users List</a></li>
                    <li><a style={{cursor: 'pointer'}} onClick={() => logoutUser()} data-after="logout">Log out</a></li>
                  </div>
                }
                {
                  (userType && userType === '1') &&
                  <div>
                    <li><a href="/createContent" data-after="Library">Create Content</a></li>
                    <li><a style={{cursor: 'pointer'}} onClick={() => logoutUser()} data-after="logout">Log out</a></li>
                  </div>
                }
              </ul>
            </div>
          </div>
        </div>
      </section>

    )
}

export default MainMenu;
