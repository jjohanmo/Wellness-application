import React from 'react';
import Cards from './cards';
import CustomCards from './customCards';
// import '../styles/quiz.css'

function Quiz(props) {
    return (
        <div data-testid="quiz-test">
            <CustomCards />
        </div>
    );
}

export default Quiz;