import React from 'react';

function AdminDashboard(props) {
    return (
        <div data-testid="admin-dashboard-test-1">
            {/* Admin Dashbaord */}
        </div>
    );
}

export default AdminDashboard;