import React from 'react';
import about from '../images/about.jpg'
import med from '../images/med.jpg'
import meditation from '../images/meditation-21.jpg'
import logo from '../images/logo.png'
import audio from '../images/audio.MP3'



const MeditationVideo = () => {
    return (
        <div>
        <section id="work" className="py-5 ">
          <div className="container ">
            <div className="row ">
              <div className="col-md-12 text-center">
                <h1 className="section-title">Meditation <span>Sample</span></h1>
                <p>Check the Meditation Sample Video</p>
              </div>
              <div className="col-md-6 text-center mx-auto">
                <a href="https://www.youtube.com/embed/syx3a1_LeFo" className="video" data-video="images/modalVideo.mp4" data-toggle="modal" data-target="#firstModal"><i className="fas fa-play fa-3x" /></a>
              </div>
            </div>
          </div>
        </section>
        <div id="firstModal" className="modal fade" role="dialog">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-body">
                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
                <iframe width={450} height={200} src="https://www.youtube.com/embed/syx3a1_LeFo" title="YouTube video player" frameBorder={0} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
              </div>
            </div>
          </div>
        </div>
      </div>
          
    ) 
}
    export default MeditationVideo;