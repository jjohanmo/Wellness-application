import React from 'react';
import logo from '../images/logo.png'




const About = () => {
    return (
        <section id="about" className="py-5 mt-5">
          <div className="about containerh">
            <div className="about-top">
              <h1 className="section-title">About <span>Us</span></h1>
            </div>
            <div className="container ">
              <div className="row ">
                <div className="col-md-6 text-center">
                  <div className="historyArea">
                    <p>The Wellness app is the web-based and mobile-compatible application consists of a personal assistant that allows users to tailor a subset of focus and/or relaxation techniques from a selected catalogue to their specific habits and daily schedule.</p>
                  </div>
                </div>
                <div className="col-md-6 text-center">
                  <div className="historyImage">
                    <img src={logo} className="img-fluid" alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div></section>
          
    ) 
}
    export default About;