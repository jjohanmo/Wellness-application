import React from 'react';


const Welcome = () => {
    return (
<div>
          <div>
            <section id="home">
              <div className="home containerh">
                <div>
                  <h1>Welcome, <span /></h1>
                  <h1>To <span /></h1>
                  <h1><b>Wellness App <b><span /></b></b></h1><b><b>
                    <a href="#about" type="button" className="cta">About Us</a>
                  </b></b></div><b><b>
                  </b></b></div><b><b>
                  </b></b></section><b><b>
                  </b></b></div>
        </div>
    )
}
export default Welcome;