import React, {useState, useEffect} from 'react';
import '../index.css';
import AdminDashboard from './adminDashboard';
import CreatorDashboard from './creatorDashboard';
import PublicDashboard from './publicDashboard';
import { useAuth0 } from "@auth0/auth0-react";

function Dashboard(props) {
    const { user } = useAuth0();
    const [userType, setUserType] = useState(0);

    const serverUrl = process.env.REACT_APP_FLASK_SERVER_URL;

    useEffect(() => {
        setUserType(localStorage.getItem('userType') ?? '0')
        localStorage.setItem('userData', JSON.stringify(user))

        if(user){
            //api to check whether user already exist
            fetch(serverUrl+'/GetUserByEmail?email='+user.email, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            .then((response) => response.json())
            .then((data) => {
                console.log("userdata900", data)
                if(!data.Email){
                    let userDetails = {
                        'RoleId': Number(userType)+1,
                        'StatusId': 1,
                        'Email': user.email,
                        'FirstName': user.given_name,
                        'LastName': user.family_name,
                        'RegisterDate': String(new Date()),
                        'IsDeleted': false
                    }
                    fetch(serverUrl+'/AddNewUser', {
                        method: 'POST', // or 'PUT'
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(userDetails),
                    })
                    .then((response) => response.json())
                    .then((userId) => {
                        console.log("userId", userId)
                        localStorage.setItem('userId', userId)

                    })
                    .catch((error) => {
                        console.error('Error:', error);
                    });
                }
                else{
                    console.log("already a  user",data)
                    localStorage.setItem('userId', data.UserId)
                }

            })
            .catch((error) => {
                console.error('Error:', error);
            });
        }

    });

    return (
        <div data-testid="dashboard-test-1">
            <h1 style={{marginTop: "150px", textAlign: "center", marginBottom: "30px"}}><i>Start your wellness journey today!</i></h1>
            <div className='dashboard-container'>

            </div>
            {
                userType == '2' &&
                <PublicDashboard/>
            }
            {
                userType == '1' &&
                <CreatorDashboard/>
            }
            {
                userType == '0' &&
                <AdminDashboard/>
            }

        </div>
    );
}

export default Dashboard;