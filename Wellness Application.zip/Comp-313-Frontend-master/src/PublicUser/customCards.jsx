import React, { useEffect, useState }  from 'react';
import { useNavigate } from "react-router-dom";

import CustomCard from './customCard';
import Recommendations from './recommendations';

import Button from '@mui/material/Button';

import logomenu from "../images/logomenu.png"

import { useAuth0 } from '@auth0/auth0-react';

import '../index.css';
import '../styles/customCards.css'

function CustomCards(props) {
    const {logout} = useAuth0();

    const [questionList, setQuestionList] = useState([])
    const [contentRecommended, setContentRecommended] = useState([])
    const [redirect, setRedirect] = useState(false)
    const [answer, setAnswer] = useState(-1)

    const [questionIndex, setQuestionIndex] = useState(0);

    useEffect(()=>{
        fetchAllQuestions()
    },[])

    const serverUrl = process.env.REACT_APP_FLASK_SERVER_URL;

    const fetchAllQuestions = () => {
        fetch(serverUrl+'/Questions', {
            method: 'GET', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then((response) => response.json())
        .then((data) => {
            setQuestionList(data)

        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }


    const prevQuestionClick = () => {
        if(questionIndex === 0){
            return;
        }

        setQuestionIndex(questionIndex-1);
        setAnswer(-1)
    }

    const nextQuestionClick = () => {
        if(questionIndex === questionList.length-1){
            return;
        }

        setQuestionIndex(questionIndex+1);
        setAnswer(-1)
    }

    const submitClick = () => {
        let result = {}

        questionList.forEach((question,index)=>{
            if(index<6){
                let keyString = 'q'+ (index+1)
                result[keyString] = question.userResponse ?? 1
            }

        })

        fetch(serverUrl+'/Recommendations', {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(result),
        })
        .then((response) => response.json())
        .then((data) => {

            setContentRecommended(data)
            setRedirect(true)
            localStorage.setItem('recommendations', JSON.stringify(data))
            // navigate('/recommendations', data);
            window.location = '/recommendations'
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }

    const selectAnswer = (optionIndex) => {
        questionList[questionIndex]['userResponse'] = optionIndex+1;
        setQuestionList(questionList)
    }

    return (
        <div>
            {/* {
                redirect &&
                <Recommendations
                    content={contentRecommended}
                />
            } */}
            <div className="container-cards">
                <h4 className="question-title">Question no: {questionIndex+1}</h4>
                <CustomCard
                    question={questionList[questionIndex]}
                    selectAnswer={selectAnswer}
                    answer={answer}
                    setAnswer={setAnswer}
                />
                <Button onClick={()=>prevQuestionClick()} className="prev-button" variant="contained">Previous</Button>

                {
                    questionIndex < questionList.length - 1 ?
                    <Button onClick={()=>nextQuestionClick()} className="next-button" variant="contained">Next</Button>
                    :
                    <Button onClick={()=>submitClick()} className="next-button"  variant="contained">Submit</Button>
                }
            </div>
            <div>

            </div>


        </div>
    );
}

export default CustomCards;