import React from 'react';


const Features = () => {
    return (
<section id="features" className="py-5">
  <div className="container">
    <div className="row mt-5 ">
      <div className="col-md-4 text-center">
        <i className="fas fa-play fa-4x" />
        <h3 className="mt-3"> Meditation Video </h3>
        <p>Meditation is considered a type of mind-body complementary medicine. 
          Meditation can produce a deep state of relaxation and a tranquil mind. 
        </p>
      </div>
      <div className="col-md-4 text-center">
        <i className="fas fa-music fa-4x" />
        <h3 className="mt-3">Focus Audio</h3>
        <p>Focus musicallow you to access different sound frequencies for relaxation.</p>
      </div>
      <div className="col-md-4 text-center">
        <i className=" fas fa-comment-dots fa-4x" />
        <h3 className="mt-3">Free Consultation</h3>
        <p>Free Consultation and One-one ineraction with our experts</p>
      </div>
    </div>
  </div>
</section>
    )
}
export default Features;
