import React from 'react';

function PublicDashboard(props) {
    return (
        <div  data-testid="public-test-1">
        </div>
    );
}

export default PublicDashboard;