import {render, screen, cleanup} from '@testing-library/react'
import Dashboard from '../dashboard'
import AdminDashboard from '../adminDashboard'
import PublicDashboard from '../publicDashboard'
import '@testing-library/jest-dom'

afterEach(()=>{
    cleanup();
})

test('should render Dashboard component',()=>{
    render(<Dashboard/>);
    const dashboardElement = screen.getByTestId('dashboard-test-1');
    expect(dashboardElement).toBeInTheDocument();
})

test('should render Admin Dashboard component',()=>{
    render(<AdminDashboard/>);
    const dashboardElement = screen.getByTestId('admin-dashboard-test-1');
    expect(dashboardElement).toBeInTheDocument();
})

test('should render Public Dashboard component',()=>{
    render(<PublicDashboard/>);
    const dashboardElement = screen.getByTestId('public-test-1');
    expect(dashboardElement).toBeInTheDocument();
})
